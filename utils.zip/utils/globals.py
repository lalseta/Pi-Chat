
global client_users
global pi_users
global admin_users
global namespaces
